'use strict';

import home from '../components/home.vue';
import detail from '../components/detail.vue';
import creditmoredetail from '../components/creditmoredetail.vue';
import installmentmoredetail from '../components/installmentmoredetail.vue';
import activedetail from '../components/activedetail.vue';

export default [
	{
		path: '/home/',
		component: home,
		options: {
			history: true,
			pushState: true,
		}
	},
	{
		path: '/detail/',
		component: detail,
		options: {
			history: true,
			pushState: true,
		}
	},
    {
        path: '/installmentmoredetail/',
        component: installmentmoredetail,
        options: {
        	history: true,
        	pushState: true,
        }
    },
    {
        path: '/creditmoredetail/',
        component: creditmoredetail,
		options: {
        	history: true,
        	pushState: true,
        }
    },
    {
        path: '/activedetail/',
        component: activedetail,
		options: {
        	history: true,
        	pushState: true,
        }
    }
];