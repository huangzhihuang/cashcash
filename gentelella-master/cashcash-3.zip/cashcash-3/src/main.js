'use strict';

import 'framework7/dist/css/framework7.material.min.css';

// Import F7, F7-Vue
import Framework7 from 'framework7';
import Framework7Vue from 'framework7-vue';

import Vue from 'vue';
import App from './App';
import router from './router';

// Init network framework
import axios from './network';

import {ERRCODE, API} from './lib/CONST';
// Init Vue Plugin
Vue.use(Framework7Vue);

Vue.config.productionTip = false;
Vue.prototype.axios = axios;
Vue.prototype.errcode = ERRCODE;
Vue.prototype.api = API;

/* eslint-disable no-new */
new Vue({
	el: '#app',
	template: '<App/>',
	components: {App},
	framework7: {
		root: '#app',
		routes: router
	}
});
