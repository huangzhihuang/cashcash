<style lang="scss">
@import "cashcash";
</style>
<template>
    <!-- App -->
  <div id="app">
    <!-- Statusbar -->
    <f7-statusbar style="background: #2C2C2C;"></f7-statusbar>
    <f7-views>
    	<f7-view navbar-fixed main url="/home/"></f7-view>
    </f7-views>
	</div>
</template>
<script>
export default {
  name: 'app',
}
</script>