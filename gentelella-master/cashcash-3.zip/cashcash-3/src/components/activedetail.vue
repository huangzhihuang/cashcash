<template>
    <f7-page id="adtivedetail" no-navbar>
    <div slot="fixed" class="home-navbar">
        <a href="#" class="back link"><i class="icon icon-back"></i></a>
        {{product}}
    </div>
    <f7-tabs swipeable>
        <f7-page-content tab>
            <iframe id='iframe' :src="src" frameborder="0"></iframe>
        </f7-page-content>
    </f7-tabs>
    <f7-fab v-if="cap_status==0" id="download-btn" :href="jump_url" @click="click" class="external">
        Download dan Pinjam dari {{product}}
    </f7-fab>
    <f7-fab v-if="cap_status == 1" id="download-btn" class="caplimit" @click="click">
        Sudah mencapai limit harian
    </f7-fab>
  </f7-page>
</template>
<script>
	export default {
    	name: 'activedetail',
    	data() {
    		return {
    			src: '',
    			jump_url: '',
    			product: '',
                cap_status: 0
    		};
    	},
        methods: {
            click() {
                gtag('event', 'h5_tips_details_download_click', {
                    value: 1,
                    event_label: this.product
                });
            }
        },
    	mounted() {
            const iframe = document.getElementById('iframe'); 
            if (iframe.attachEvent){ 
                iframe.attachEvent('onload', () => {
                    gtag('event', 'h5_tips_detail_pageview', {'value': 1});
                    // this.$f7.hidePreloader();
                }); 
            } else { 
                iframe.onload = () => { 
                    gtag('event', 'h5_tips_detail_pageview', {'value': 1});
                    // this.$f7.hidePreloader(); 
                }; 
            } 
            // this.$f7.showPreloader();
	        this.src = decodeURIComponent(this.$route.query.src);
	        this.jump_url = decodeURIComponent(this.$route.query.jump_url);
	        this.product = this.$route.query.product;
            this.cap_status = this.$route.query.cap_status;
	    }
    }
</script>