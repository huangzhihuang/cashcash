<template>
  <f7-page id="home" no-navbar>
    <div slot="fixed" class="home-navbar">
        <a href="#credit" :class="curtab==='credit'?'link active':'link'" @click="showCredit">UANG TUNAL</a>
        <a href="#installment" :class="curtab==='installment'?'link active':'link'" @click="showInstallment">CICILAN</a>
        <a href="#activity" :class="curtab==='activity'?'link active':'link'" @click="showActivity">TIPS</a>
    </div>
    <div slot="fixed" id="home-download">
        <a href="https://play.google.com/store/apps/details?id=com.firestorm.sea.cashcash" class="external"></a>
    </div>
    <!-- </div> -->
    <f7-tabs swipeable>
        <f7-page-content id="credit" tab :style="`display:${curtab==='credit'?'block':'none'};`" @tab:show="showCredit(true)">
            <f7-block class="banner">
                <div id="creditBanner" class="swiper-container">
                    <div class="swiper-wrapper"></div>
                </div>
            </f7-block>
            <f7-block v-for="(item,n) in creditList" :key="n" class='item'>
                <f7-link @click="creditListClick" :href="'/detail?type=credit&pid=' + item.pid">
    	            <div class="head">
    	                <img :src="item.icon" class="offer-icon">
    	                <span class="title">{{item.product_name}}</span>
    	                <span class="score">{{ForDight(item.total_score, 1)}}</span>
                        <span v-if="item.cap_status==0" class="btn">Ajukan</span>
                        <span v-if="item.cap_status==1" class="btn btn-cap">Penuh</span>
    	            </div>
    	            <div class="info">
    	                <div class="info-left">
    	                    <div class="info-left-money">{{item.price_new}}</div>
    	                    <div>Jumlah maksimum</div>
    	                </div>
    	                <div class="info-right">
                            <div class="info-right-wrap">
        	                    <div>Bunga≥{{item.interest_rate}}%/{{item.interest_rate_unit}}</div>
        	                    <div>Proses {{item.loan_time_day}} hari</div>
                            </div>
    	                </div>
    	            </div>
    	            <div class="foot">
    	                {{item.review}}
    	            </div>
                </f7-link>
            </f7-block>
        </f7-page-content>
        <f7-page-content id="installment" tab :style="`display:${curtab==='installment'?'block':'none'};`" @tab:show="showInstallment(true)">
            <f7-block class="banner">
                <div id="installmentBanner" class="swiper-container">
                    <div class="swiper-wrapper"></div>
                </div>
            </f7-block>
            <f7-block v-for="(item,n) in installmentList" :key="n" class='item'>
                <f7-link @click="installmentListClick" :href="'/detail?type=installment&pid=' + item.pid">    
                    <div class="head">
                        <img :src="item.icon" class="offer-icon">
                        <span class="title">{{item.product_name}}</span>
                        <span class="score">{{item.total_score}}</span>
                        <span v-if="item.cap_status==0" class="btn">Ajukan</span>
                        <span v-if="item.cap_status==1" class="btn btn-cap">Penuh</span>
                    </div>
                    <div class="info">
                        <div class="info-left">
                            <div class="info-left-percent">{{paymentRate(item.down_payment_rate_min, item.down_payment_rate_max)}}</div>
                            <div>Uang muka</div>
                        </div>
                        <div class="info-right">
                            <div class="info-right-wrap">
                                <div>Bunga≥{{item.interest_rate}}%/bulan</div>
                                <div>Durasi {{item.staging_cycle_min}}-{{item.staging_cycle_max}}bulan</div>
                            </div>
                        </div>
                    </div>
                    <div class="foot">
                        {{item.review}}
                    </div>
                </f7-link>
            </f7-block>
        </f7-page-content>
        <f7-page-content id="activity" tab :style="`display:${curtab==='activity'?'block':'none'};`" @tab:show="showActivity">
            <f7-block v-for="item in activityList" :key="item.pid" class='tip-item'>
                <f7-link @click="tipsListClick" :href="activedetail(item.url, item.jump_url, item.product_name, item.cap_status)"> 
                    <div class="info-left">
                        <div class="info-left-title">{{item.title}}</div>
                    </div>
                    <div class="info-right">
                        <img :src="item.icon" class="tip-icon">
                    </div>
                </f7-link>
            </f7-block>
        </f7-page-content>
    </f7-tabs>
  </f7-page>
</template>
<script>
// import { Swiper, Autoplay, Scrollbar } from 'swiper/dist/js/swiper.esm.js';
import drawImage from '../lib/drawImage';

// Swiper.use([Autoplay, Scrollbar]);
import * as Swiper from 'swiper/dist/js/swiper.js';
const evt = 'onorientationchange' in window ? 'orientationchange' : 'resize';
export default {
    name: 'home',
    data() {
        return {
            // 现金贷banner
            creditBanner: [],
            // 分期banner
            installmentBanner: [],
            // 现金贷列表
            creditList: [],
            // 分期列表
            installmentList: [],
            // 攻略列表
            activityList: [],
            curtab: 'credit',
            $creditBanner: null,
            $installmentBanner: null,
            width: 0,
            height: 0,
            creditRefreshing: false,
            installmentRefreshing: false,
            activityRefreshing: false
        }
    },
    mounted() {
        document.getElementById('credit').addEventListener('scroll', this.handleScroll);
        document.getElementById('installment').addEventListener('scroll', this.handleScroll);
        document.getElementById('activity').addEventListener('scroll', this.handleScroll);
        this.width = document.getElementById('creditBanner').getBoundingClientRect().width;
        this.height = document.getElementById('creditBanner').getBoundingClientRect().height;

        // window.addEventListener(evt, this.resize, false);
        this.showCredit(true);
    },
    methods: {
        ForDight(Dight, How){  
            Dight = Math.round(Dight*Math.pow(10,How))/Math.pow(10,How);  
            return Dight;  
        },
        creditBannerClick() {
            gtag('event', 'h5_credit_banner_click', {
                value: 1
            });
        },
        installmentBannerClick() {
            gtag('event', 'h5_cicilan_banner_click', {
                value: 1
            });
        },
        creditListClick() {
            gtag('event', 'h5_credit_list_click', {
                value: 1
            });
        },
        installmentListClick() {
            gtag('event', 'h5_cicilan_list_click', {
                value: 1
            });
        },
        tipsListClick() {
            gtag('event', 'h5_tips_list_click', {
                value: 1
            });
        },
        activedetail(url, jump_url, product, cap_status) {
            return `/activedetail?cap_status=${cap_status}&product=${product}&src=${encodeURIComponent(url)}&jump_url=${encodeURIComponent(jump_url)}`;
        },
        paymentRate (down_payment_rate_min, down_payment_rate_max) {
            if (down_payment_rate_min !== down_payment_rate_max && down_payment_rate_min && down_payment_rate_max) {
                return `${parseInt(down_payment_rate_min)} ~ ${parseInt(down_payment_rate_max)}`;
            }
            else {
                return parseInt(down_payment_rate_min);
            }
        },
        drawBanner(type) {
            let swiperList = [];
            this[type].map(item=>{
                swiperList.push(`
                    <div class="swiper-slide">
                        <a href="/detail?type=credit&pid=${item.pid}"><canvas width=${this.width} height=${this.height} class="swiper-img $${type}" data-img=${item.img}>
                            <img class="swiper-img" src=${item.img}>
                        </canvas></a>
                    </div>`);
            });
            type = `$${type}`;
            // this[type].destroy();
            this[type].appendSlide(swiperList);
            drawImage(type);
        },
        showCredit(getBanner) {
            this.curtab = 'credit';
            gtag('event', 'h5_credit_list_pageview', {
                value: 1
            });
            // 现金贷banner
            if (getBanner) {
                this.axios.post(this.api.banner, {banner_type: 1})
                .then(response => {
                    this.creditBanner = response.banner;
                    if (this.$creditBanner) {
                        this.$creditBanner.removeAllSlides();
                        this.$creditBanner.destroy(true, true);
                    }
                    this.$creditBanner = new Swiper ('#creditBanner', {
                        on: {
                            click: function () {
                                gtag('event', 'h5_credit_banner_click', {
                                    value: 1
                                });
                            }
                        },
                        loop: true,
                        autoplay: response.banner.length > 1 ? {
                            delay: 5000,
                            disableOnInteraction: false
                        } : false 
                    });
                    this.drawBanner('creditBanner');
                    response.length > 1 && this.$creditBanner.autoplay.start();
                })
                .catch(function (error) {});
            }
            // 现金贷列表
            if (!this.creditRefreshing) {
                if (this.creditList.length === 0) {
                    this.$f7.showPreloader();
                }
                this.creditRefreshing = true;
                this.axios.post(this.api.creditList, {start: this.creditList.length,limit: 10})
                .then(response => {
                    this.$f7.hidePreloader();
                    this.creditRefreshing = false
                    this.creditList = this.creditList.concat(response);
                })
                .catch(function (error) {
                    this.$f7.hidePreloader();
                });
            }
        },
        showInstallment(getBanner) {
            this.curtab = 'installment';
            gtag('event', 'h5_cicilan_list_pageview', {
                value: 1
            });
            // 分期banner
            if (getBanner) {
                this.axios.post(this.api.banner, {banner_type: 2})
                .then(response => {
                    this.installmentBanner = response.banner;
                    if (this.$installmentBanner) {
                        this.$installmentBanner.removeAllSlides();
                        this.$installmentBanner.destroy(true, true);
                    }
                    this.$installmentBanner = new Swiper ('#installmentBanner', {
                        on: {
                            click: function () {
                                gtag('event', 'h5_cicilan_banner_click', {
                                    value: 1
                                });
                            }
                        },
                        loop: true,
                        autoplay: response.banner.length > 1 ? {
                            delay: 5000,
                            disableOnInteraction: false
                        } : false
                    });
                    this.drawBanner('installmentBanner');
                })
                .catch(function (error) {});
            }
            // 分期列表
            if (!this.installmentRefreshing) {
                if (this.installmentList.length === 0) {
                    this.$f7.showPreloader();
                }
                this.installmentRefreshing = true;
                this.axios.post(this.api.installmentList, {start: this.installmentList.length,limit: 10})
                .then(response => {
                    this.$f7.hidePreloader();
                    this.installmentRefreshing = false;
                    this.installmentList = this.installmentList.concat(response);
                })
                .catch(function (error) {
                    this.$f7.hidePreloader();
                });
            }
        },
        showActivity() {
            gtag('event', 'h5_tips_list_pageview', {
                value: 1
            });
            this.curtab = 'activity';
            // 获取产品攻略列表
            if (!this.activityRefreshing) {
                if (this.activityList.length === 0) {
                    this.$f7.showPreloader();
                }
                this.activityRefreshing = true;
                this.axios.post(this.api.activity)
                .then(response => {
                    this.$f7.hidePreloader();
                    // this.activityRefreshing = false;
                    this.activityList = this.activityList.concat(response);
                })
                .catch(function (error) {
                    this.$f7.hidePreloader();
                });
            }
        },
        handleScroll () {
            let element = document.getElementById(this.curtab);
            if (element.scrollHeight - element.scrollTop - element.clientHeight < 20) {
                if (this.curtab === 'credit') {
                    this.showCredit(false);
                }
                else if (this.curtab === 'installment') {
                    this.showInstallment(false);
                }
                else if (this.curtab === 'activity') {
                    this.showActivity();
                }
            }
            element = null;
        }
    },
    beforeDestroy() {
        document.getElementById('credit').removeEventListener('scroll', this.handleScroll);
        document.getElementById('installment').removeEventListener('scroll', this.handleScroll);
        document.getElementById('activity').removeEventListener('scroll', this.handleScroll);
        // window.removeEventListener(evt, this.resize);
    }
}
</script>
