<template>
  <f7-page id="detail" no-navbar>
    <div slot="fixed" class="home-navbar">
        <a href="#" class="back link"><i class="icon icon-back"></i></a>
        <a href="#info" :class="curtab==='info'?'link active':'link'" @click="info">DETAIL</a>
        <a href="#flow" :class="curtab==='flow'?'link active':'link'" @click="flow">GUIDE</a>
        <a href="#comment" v-if="review.user_review.length" :class="curtab==='comment'?'link active':'link'" @click="comment">KOMENTAR</a>
    </div>
    <f7-tabs swipeable>
        <f7-page-content id="content-wrap" tab>
        <!-- <div id="content-wrap"> -->
            <f7-block class="detail-item detail-item-1">
                <div class="head">
                    <div class="titel-wrap">
                        <span class="title">{{detail.product_name}}</span>
                        <span class="score">{{ForDight(detail.total_score, 1)}}</span>
                        <f7-link @click="detailClick" :href="`/${path}?pid=${this.pid}`">
                            <span class="btn right">Details</span>
                        </f7-link>
                    </div>
                    <div class="sub-title">
                        <span class="sub-title-item">Lulus{{detail.pass_rate_score}}</span>
                        <span class="sub-title-item" v-if="type === 'credit'">Kecepatan{{detail.speed_score}}</span>
                        <span class="sub-title-item">Penagihan{{detail.dunning_score}}</span>
                    </div>
                </div> 
                <div class="info">
                    <div class="info-item" v-for="(item, n) in detail.details_info" :key="n" >{{item.content}}</div>
                </div>
            </f7-block>
            <f7-block v-if="detail.price.length || detail.interest_algorithm.length" class="detail-item detail-item-2">
                <div v-if="type === 'credit'" class="ruler">
                    <div v-if="classify" class="ruler-item">
                        <div class="ruler-item-select">
                            <select v-model="creditType">
                                <option v-for="(item, key, n) in typeList" :key="n" :value="key">{{key}}</option>
                            </select>
                        </div>
                        <div class="ruler-title">Jenis</div>
                    </div>
                    <div class="ruler-item">
                        <div class="ruler-item-select">
                            <select v-model="price">
                                <option v-for="(item, key, n) in priceList" :key="n" :value="key">Rp {{thousands(key)}}</option>
                            </select>
                        </div>
                        <div class="ruler-title">Jumlah: 
                        {{priceCreditMin == priceCreditMax
                        ? `Rp ${thousands(priceCreditMin)}`
                        : `Rp ${thousands(priceCreditMin)} ~ ${thousands(priceCreditMax)}`}}</div>
                    </div>
                    <div class="ruler-item">
                        <div class="ruler-item-select">
                            <select v-model="time">
                                <option v-for="n in timeList" :key="n" :value="n">{{n}} Hari</option>
                            </select> 
                        </div>
                        <div class="ruler-title">Waktu: {{timeList.length < 2 ? timeList[0] : timeList[0] + '~' + timeList[timeList.length-1]}} Hari</div>
                    </div>
                </div>
                <div v-else>
                    <div v-if="classify" class="ruler">
                        <div class="ruler-item">
                            <div class="ruler-item-select">
                                <select v-model="installmentType">
                                    <option v-for="(item, key, n) in typeList" :key="n" :value="key">{{key}}</option>
                                </select>
                            </div>
                            <div class="ruler-title">Jenis</div>
                        </div>
                        <div class="ruler-item">
                            <div class="ruler-item-select">
                                <select v-model="paymentRate">
                                    <option v-for="n in typeList[installmentType].down_payment_rate" :key="n" :value="n">{{parseInt(n)}} %</option>
                                </select>
                            </div>
                            <div class="ruler-title">Uang muka: 
                            {{typeList[installmentType].down_payment_rate_min == typeList[installmentType].down_payment_rate_max ? parseInt(typeList[installmentType].down_payment_rate_min) : `${parseInt(typeList[installmentType].down_payment_rate_min)} ~ ${parseInt(typeList[installmentType].down_payment_rate_max)}`}}
                            %</div>
                        </div>
                    </div>
                    <div v-if="classify" class="ruler">
                        <div class="ruler-item">
                            <div class="ruler-item-select">
                                <input v-model.lazy="price" type="text">
                            </div>
                            <div class="ruler-title">Jumlah:
                                {{typeList[installmentType].price_min == typeList[installmentType].price_max ? 'nominal ditentukan ......' : (
                                    typeList[installmentType].price_max == 0
                                    ? `Rp minimal ${thousands(typeList[installmentType].price_min)}`
                                    : `Rp${thousands(typeList[installmentType].down_payment_rate_min)} ~ ${thousands(typeList[installmentType].price_max)}`
                                )}}
                            </div>
                        </div>
                        <div class="ruler-item">
                            <div class="ruler-item-select">
                                <select v-model="time">
                                    <option v-for="n in typeList[installmentType].timeList" :key="n" :value="n">{{n}} Hari</option>
                                </select>
                            </div>
                            <div class="ruler-title">Waktu: 
                            {{typeList[installmentType].time_min == typeList[installmentType].time_max ? typeList[installmentType].time_min : `${typeList[installmentType].time_min} ~ ${typeList[installmentType].time_max}`}}Hari</div>
                        </div>
                    </div>
                    <div v-if="!classify" class="ruler">
                        <div class="ruler-item">
                            <div class="ruler-item-select">
                                <select v-model="paymentRate">
                                    <option v-for="n in typeList[installmentType].down_payment_rate" :key="n" :value="n">{{parseInt(n)}} %</option>
                                </select>
                            </div>
                            <div class="ruler-title">Uang muka: 
                            {{typeList[installmentType].down_payment_rate_min == typeList[installmentType].down_payment_rate_max ? parseInt(typeList[installmentType].down_payment_rate_min) : `${parseInt(typeList[installmentType].down_payment_rate_min)} ~ ${parseInt(typeList[installmentType].down_payment_rate_max)}`}}
                            %</div>
                        </div>
                        <div class="ruler-item">
                            <div class="ruler-item-select">
                                <input v-model.lazy="price"  type="text">
                            </div>
                            <div class="ruler-title">Jumlah:
                                {{typeList[installmentType].price_min == typeList[installmentType].price_max ? 'nominal ditentukan ......' : (
                                    typeList[installmentType].price_max == 0
                                    ? `Rp minimal ${thousands(typeList[installmentType].price_min)}`
                                    : `Rp${thousands(typeList[installmentType].down_payment_rate_min)} ~ ${thousands(typeList[installmentType].price_max)}`
                                )}}
                            </div>
                        </div>
                        <div class="ruler-item">
                            <div class="ruler-item-select">
                                <select v-model="time">
                                    <option v-for="n in typeList[installmentType].timeList" :key="n" :value="n">{{n}} Hari</option>
                                </select> 
                            </div>
                            <div class="ruler-title">Waktu: {{typeList[installmentType].time_min == typeList[installmentType].time_max ? typeList[installmentType].time_min : `${typeList[installmentType].time_min} ~ ${typeList[installmentType].time_max}`}}Hari</div>
                        </div>
                    </div>
                </div>
                <div class="result-wrap">
                    <div class="ruler-title">
                        <div>Rp {{thousands(totalPay)}}</div>
                        <div>Pembayaran</div>
                    </div>
                    <div class="ruler-title">
                        <div>Rp {{thousands(actualMoney)}}</div>
                        <div>Uang muka</div>
                    </div>
                    <div class="ruler-title">
                        <div>Rp {{thousands(rate)}}</div>
                        <div>Bunga</div>
                    </div>
                </div>
            </f7-block>
            <f7-block v-if="detail.activity_list.length" class="detail-item detail-item-3">
                <div class="sub-content-block" v-for="item in detail.activity_list" :key="item.pid">
                    <f7-link @click="tipsListClick" :href="activedetail(item.url, detail.jump_url, product, detail.cap_status)"> 
                        <div class="info-left">
                            <div class="info-left-title">{{item.title}}</div>
                            <div v-for="(item, n) in item.tags" :key="n" :class="n === 0 ? 'info-left-btn label' : 'info-left-btn'">{{item}}</div>
                        </div>
                        <div class="info-right">
                            <img :src="item.icon" class="tip-icon">
                        </div>
                    </f7-link>
                </div>
            </f7-block>
            <f7-block v-if="type === 'credit'" class="detail-item detail-item-4" :id="type === 'credit' ? 'flow' : ''">
                <div class="title">Proses Peminjaman</div>
                <div class="sub-content-block" v-for="item in procedure" :key="item.step">
                    <img :src="item.icon" class="flow-icon">
                    <span class="flow-title">{{item.step}}.{{item.title}}</span>
                </div>
            </f7-block>
            <f7-block class="detail-item detail-item-5" :id="type !== 'credit' ? 'flow' : ''">
                <div class="title">Informasi Audit</div>
                <div class="sub-content-block" v-for="item in audit_info" :key="item.step">
                    <div>
                        <img :src="item.icon" class="flow-icon">
                        <span class="flow-title">{{item.sort}}.{{item.title}}</span>
                    </div>
                    <div class="audit-info">
                        <div class="sub-info" v-for="(subitem, n) in item.describe.split('\n')" :key="n" >{{subitem}}</div>
                    </div>
                </div>
            </f7-block>
            <f7-block v-if="review.user_review.length" class="detail-item detail-item-6" id="comment">
                <div class="title">Komentar</div>
                <div class="sub-content-block label-wrap">
                    <div class="label">
                        <span>Google play</span>
                        <span class="score">{{ForDight(review.google_score, 1)}}</span>
                        <span class="rank">{{review.google_ranking}}</span>
                    </div>
                </div>
                <div :class="item.tag == 1 ? 'sub-content-block good' : 'sub-content-block'" v-for="(item, n) in review.user_review" :key="n">
                    <div class="user-info">
                        <img :src="item.head_img" alt="cashcash" class="head-icon" onerror="this.src='http://h5.cashcash.id/mdpi.png'">
                        <div class="user-title">
                            <div class="nickname">{{item.nickname}}</div>
                            <div>
                                <span class="user-score">Penilaian: {{ForDight(item.score, 1)}}</span>
                                <span class="date">{{item.review_date|date('mm/dd/yyyy')}}</span>
                            </div>
                        </div>
                    </div>
                    <div class="user-comment">
                        {{item.content}}
                    </div>
                    <div ref="more" class="more more-btn" @click="toggle(n)"></div>
                </div>
            </f7-block>
            <div v-else id="comment"></div>
            <!-- </div> -->
        </f7-page-content>
    </f7-tabs>
    <f7-fab v-if="detail.cap_status == 0" id="download-btn" @click="downloadClick" :href="detail.jump_url" class="external">
        Download dan Pinjam dari {{product}}
    </f7-fab>
    <f7-fab v-if="detail.cap_status == 1" id="download-btn" class="caplimit" @click="downloadClick">
        Sudah mencapai limit harian
    </f7-fab>
<!-- </div> -->
  </f7-page>
</template>
<script>
export default {
    name: 'detail',
    data() {
        return {
            product: '',
            $content: null,
            $flow: null,
            $comment: null,
            path: '',
            price: 0,
            paymentRate: 0,
            time: '',
            totalPay: 0,
            actualMoney: 0,
            rate: 0,
            creditType: '',
            installmentType: '',
            pid: 0,
            type: '',
            curtab: 'info',
            typeList: {},
            priceList: [],
            timeList: [],
            algorithmList: {},
            algorithm: {},
            classify: false,
            priceCreditMin: 0,
            priceCreditMax: 0,
            detail: {
                product_name: '',
                details_info: [],
                total_score: 0,
                pass_rate_score: 0,
                speed_score: 0,
                dunning_score: 0,
                ares: '',
                activity_list: [],
                price: [],
                interest_algorithm: [],
                jump_url: '',
                cap_status: 0
            },
            procedure: [],
            audit_info: [],
            review: {
                user_review: []
            },
            update: false
        }
    },
    filters: {
        date(value, format) {
            value = new Date(value);
            let year = value.getFullYear();
            let month = value.getMonth() + 1;
            let day = value.getDate();
            let str = format
                .replace(/dd/, ('0' + day).slice(-2))
                .replace(/yyyy/, year)
                .replace(/mm/, ('0' + month).slice(-2));
            return str;
        },
        // 格式化显示
        thousands(num) {
            num = parseInt(num).toString() + '.';
            while (/\d{4}\./.test(num)) {
                num = num.replace(/(\d+)(\d{3}\.)/, '$1.$2');
            }
            return num.slice(0,-1);
        }
    },
    watch: {
        creditType: {
            handler() {
                this.priceList = this.typeList[this.creditType];
                this.price = Object.keys(this.typeList[this.creditType])[0];
                this.priceCreditMin = this.price;
                this.priceCreditMax = Object.keys(this.typeList[this.creditType]).pop();
            }
        },
        installmentType: {
            handler() {
                this.price = Math.ceil(this.typeList[this.installmentType].price_min);
                if (+this.price == 0) {
                    this.price = 5000000;
                }
                this.paymentRate = this.typeList[this.installmentType].down_payment_rate[0];
                this.time = this.typeList[this.installmentType].timeList[0];
                this.algorithm = this.algorithmList[this.installmentType][this.time];
            }
        },
        paymentRate: {
            handler() {
                this.algorithm = this.algorithmList[this.installmentType][this.time][this.paymentRate];
                this.installmentAlgorithm();
            }
        },
        price: {
            handler() {
                gtag('event', 'h5_details_calculator_click', {
                    value: 1,
                    event_label: 'price'
                });
                if (this.type === 'credit') {
                    this.timeList = [];
                    let timeList = this.typeList[this.creditType][this.price];
                    let temp =[];
                    if (timeList.length > 1) {
                        temp = [timeList[0].time_min, timeList[1].time_min];
                    }
                    else {
                        const min = +timeList[0].time_min;
                        const max = +timeList[0].time_max;
                        for (let i = min; i <= max; i++) {
                            temp.push(i);
                        }
                    }
                    this.timeList = temp;
                    this.time = temp[0];
                    this.algorithm = this.algorithmList[this.creditType].filter(item => {
                        return +item.price_min <= +this.price && +item.price_max >= +this.price;
                    })[0];
                    let free = this.algorithm.free;
                    if (this.algorithm.free_type == 1) {
                        free = this.price * free / 100;
                    }
                    this.actualMoney = Math.ceil(this.price - free);
                    this.creditAlgorithm();
                }
                else {
                    if (this.algorithm.price_max != 0) {
                        if (+price > +this.algorithm.price_max){
                            this.$f7.alert('', 'Tidak boleh melewati batas maksimal pinjaman');
                            this.price = Math.ceil(this.algorithm.price_max);
                            return;
                        }
                    }
                    else if(this.algorithm.price_min != 0){
                        if (+price < +this.algorithm.price_min){
                            this.$f7.alert('', 'Tidak boleh melewati batas minimum pinjaman');
                            this.price = Math.ceil(this.algorithm.price_min);
                            return;
                        }
                    }
                    this.installmentAlgorithm();
                }
            }
        },
        time: {
            handler() {
                gtag('event', 'h5_details_calculator_click', {
                    value: 1,
                    event_label: 'time'
                });
                if (this.type === 'credit') {
                    this.creditAlgorithm();
                }
                else {
                    this.algorithm = this.algorithmList[this.installmentType][this.time][this.paymentRate];
                    this.installmentAlgorithm();
                }
            }
        }
    },
    created() {
        this.pid = this.$route.query.pid;
        this.type = this.$route.query.type;
        this.path = this.type === 'credit' ? 'creditmoredetail' : 'installmentmoredetail';
    },
    methods: {
        ForDight(Dight, How){  
            Dight = Math.round(Dight*Math.pow(10,How))/Math.pow(10,How);  
            return Dight;  
        },
        downloadClick() {
            gtag('event', 'h5_details_download_click', {
                value: 1,
                event_label: this.product
            });
        },
        detailClick() {
            gtag('event', 'h5_details_more_details_click', {
                value: 1
            });
        },
        tipsListClick() {
            gtag('event', 'h5_details_tips_click', {
                value: 1
            });
        },
        activedetail(url, jump_url, product, cap_status) {
            return `/activedetail?cap_status=${cap_status}&product=${product}&src=${encodeURIComponent(url)}&jump_url=${encodeURIComponent(jump_url)}`;
        },
        thousands(num) {
            num = parseInt(num).toString() + '.';
            while (/\d{4}\./.test(num)) {
                num = num.replace(/(\d+)(\d{3}\.)/, '$1.$2');
            }
            return num.slice(0,-1);
        },
        installmentAlgorithm() {
            /**
             * [dayRate description]
             * @type {Object}
             * 应还总额（必有）：分期金额+总利息
             * 首付金额（必有）：分期金额*首付比率 
             * 每月应还金额（必有）：每月应还本金+每月利息
             */
            // 首付金额
            const price = this.price;
            this.actualMoney = Math.ceil(price * this.paymentRate / 100);
            // 每月应还本金 + 每月利息
            const monthPay = (price - this.actualMoney) / this.time * 30;
            if (this.algorithm.rate_unit === 'default') {
                this.rate = monthPay + monthPay * this.algorithm.rate / 100;
            }
            else {
                this.rate = monthPay + (price - this.actualMoney) * this.algorithm.rate / 100;
            }
            this.rate = Math.ceil(this.rate);
            if (this.algorithm.rate_unit === 'default') {
                this.totalPay = +price + monthPay * this.algorithm.rate / 100 * this.time / 30;
            }
            else {
                this.totalPay = +price + (price - this.actualMoney) * this.algorithm.rate / 100 * this.time / 30;
            }
            this.totalPay = Math.ceil(this.totalPay);
        },
        creditAlgorithm() {
            /**
             * 现金贷计算规则：

                利息(因变量：interest_algorithm.rate_unit、interest_algorithm.rate、借款金额、借款周期)：
                    days：
                        借款金额 * 借款周期 * interest_algorithm.rate + 手续费
                    month：
                        借款金额 * 借款周期 * interest_algorithm.rate / 30  + 手续费
                    default：
                        固定利息  + 手续费

                实际到账(因变量：interest_algorithm.free_type, interest_algorithm.free)：
                    百分比：
                        借款金额 - 借款金额 * free
                    固定值：
                        借款金额 - free

                还款总额：
                    实际到账 + 利息
             */
            const dayRate = {
                'days': 1,
                'month': 30,
                'default': 0
            }[this.algorithm.rate_unit];

            const free = this.price - this.actualMoney;
            this.rate = dayRate ? (this.price * this.algorithm.rate /100 * this.time / dayRate + free) : (this.algorithm.rate / 100 + free);
            this.rate = Math.ceil(this.rate);
            this.totalPay = this.rate + this.actualMoney;
        },
        toggle(index) {
            let $comment = document.getElementsByClassName('user-comment')[index];
            let $more = document.getElementsByClassName('more')[index];
            if (/hide/.test($comment.className)) {
                $comment.className = 'user-comment';
                $more.className = 'more hide-btn'; 

            }
            else {
                $comment.className = 'user-comment hide';
                $more.className = 'more more-btn'; 
            }
            $comment = null;
            $more = null;
        },
        handleScroll () {
            try {
                this.$flow = document.getElementById('flow');
                this.$comment = document.getElementById('comment');
                const scrollTop = this.$content.scrollTop || this.$content.pageYOffset;
                const flowOffsetTop = this.$flow.offsetTop;
                const flowOffsetHeight = this.$flow.offsetHeight/2 ;
                const commentOffsetTop = this.$comment.offsetTop;
                const commentOffsetHeight = this.$comment.offsetHeight/2;
                if(scrollTop >= commentOffsetTop - commentOffsetHeight){
                    this.curtab = 'comment';
                }else if (scrollTop >= flowOffsetTop - flowOffsetHeight){
                    this.curtab = 'flow';
                } else {
                    this.curtab = 'info';
                }
            }catch(e){}
        },
        info() {
            this.$content.scrollTop = 0;
        },
        flow() {
            this.$flow = document.getElementById('flow');
            this.$content.scrollTop = this.$flow.offsetTop;
        },
        comment() {
            this.$comment = document.getElementById('comment');
            this.$content.scrollTop = this.$comment.offsetTop;
        }
    },
    mounted() {
        gtag('event', this.type === 'credit' ? 'h5_details_credit_pageview' : 'h5_details_cicilan_pageview', {
            value: 1
        });
        this.$content = document.getElementById('content-wrap');
        this.$content.addEventListener('scroll', this.handleScroll);
        // 详细信息
        this.$f7.showPreloader();
        this.axios.post(this.api[`${this.type}Info`], {pid: this.pid})
        .then(response => {
            this.$f7.hidePreloader();
            this.classify = false;
            this.typeList = {};
            this.algorithmList = {};
            this.algorithm = {};
            this.creditType = '';
            this.installmentType = '';
            this.price =  0,
            this.paymentRate = 0,
            this.time = '',
            this.totalPay = 0,
            this.actualMoney = 0,
            this.rate =  0,
            this.detail = Object.assign({}, this.detail, response);
            this.product = this.detail.product_name;
            if (this.type === 'credit') {
                if (response.interest_algorithm.length) {
                    response.interest_algorithm.map(item => {
                        if(this.algorithmList.hasOwnProperty(item.num)) {
                            this.algorithmList[item.num].push(item);
                        }
                        else {
                            this.algorithmList[item.num] = [item];
                        }
                    });
                }
                if (response.price.length) {
                    response.price.map(item => {
                        if(this.typeList.hasOwnProperty(item.num)) {
                            this.typeList[item.num][item.price] = item.time;
                        }
                        else {
                            this.typeList[item.num] = {}
                            this.typeList[item.num][item.price] = item.time;
                        }
                    });
                    let keys = Object.keys(this.typeList);
                    this.classify = (keys.length > 1) || (+0 != keys[0]);
                    this.creditType = keys[0];
                }
            }
            else if (this.type === 'installment') {
                if (response.price.length) {
                    response.price.map(item => {
                        this.typeList[item.num] = Object.assign({}, item)
                        let timeList = [];
                        item.time.map(item => {
                            if (timeList.indexOf(item) === -1) {
                                timeList.push(item.time_min);
                            }
                        });
                        this.typeList[item.num]['timeList'] = timeList;
                        this.typeList[item.num]['down_payment_rate_min'] = item.down_payment_rate[0];
                        this.typeList[item.num]['down_payment_rate_max'] = item.down_payment_rate[item.down_payment_rate.length-1];
                        this.typeList[item.num]['time_min'] = timeList[0];
                        this.typeList[item.num]['time_max'] = timeList[timeList.length-1];
                        this.algorithmList[item.num] = {};
                        timeList.map(key => {
                            this.algorithmList[item.num][key] = {};
                        });
                    });
                    let keys = Object.keys(this.typeList);
                    this.classify = (keys.length > 1) || (+0 != keys[0]);
                    this.installmentType = keys[0];
                }
                else {
                    if (response.interest_algorithm.length) {
                        this.typeList['0'] = Object.assign({}, response.interest_algorithm[0]);
                        this.typeList['0']['down_payment_rate_min'] = response.down_payment_rate[0];

                        let timeList = [];
                        response.interest_algorithm.map(item => {
                            if (timeList.indexOf(item.time_min) === -1) {
                                timeList.push(item.time_min);
                            }
                        });
                        
                        this.typeList['0']['timeList'] = timeList;
                        this.typeList['0']['time_min'] = timeList[0];
                        this.typeList['0']['time_max'] = timeList[timeList.length-1];
                        this.typeList['0']['down_payment_rate_max'] = response.down_payment_rate[response.down_payment_rate.length-1];
                        this.typeList['0']['down_payment_rate'] = response.down_payment_rate;
                        this.installmentType = '0';
                        this.algorithmList['0'] = {};
                        timeList.map(item => {
                            this.algorithmList['0'][item] = {};
                        });
                    }
                }
                if (response.interest_algorithm.length) {
                    response.interest_algorithm.map(item => {
                        let keys = Object.keys(this.algorithmList[item.num]);
                        keys.map(key => {
                            if (+key <= +item.time_max && +key >= +item.time_min) {
                                if(this.algorithmList[item.num].hasOwnProperty(key)) {
                                    this.algorithmList[item.num][key][item.down_payment_rate] = item;
                                }
                                else {
                                    this.algorithmList[item.num][key] = {};
                                    this.algorithmList[item.num][key][item.down_payment_rate] = item;
                                }
                            }
                        });
                    });
                }
            }
        })
        .catch(function (error) {
            this.$f7.hidePreloader();
        });
        // 流程
        this.axios.post(this.api[`${this.type}Procedure`], {pid: this.pid})
        .then(response => {
            this.procedure = response.procedure;
            this.audit_info = response.audit_info;
        })
        .catch(function (error) {});
        // 评论
        this.axios.post(this.api[`${this.type}Review`], {pid: this.pid})
        .then(response => {
            this.review = response;
            this.update = true;
        })
        .catch(function (error) {});
    },
    updated() {
        if (this.$refs.more && this.update) {
            this.update = false;
            this.$refs.more.map(item=>{
                const $commet = item.previousElementSibling;
                const style = $commet.currentStyle ? $commet.currentStyle : getComputedStyle($commet, false);
                const lh = parseFloat(style.lineHeight);
                const h = parseFloat(style.height);
                if (h / lh > 3) {
                    $commet.className = 'user-comment hide';
                }
                else {
                    item.style.display = 'none'; 
                }
            });
        }
    },
    beforeDestroy() {
        this.$content.removeEventListener('scroll', this.handleScroll);
    }
}
</script>
