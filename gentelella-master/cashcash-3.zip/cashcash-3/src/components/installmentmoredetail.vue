<template>
    <f7-page id="more-detail" no-navbar>
    <div slot="fixed" class="home-navbar">
        <a href="#" class="back link"><i class="icon icon-back"></i></a>
        {{detail.product_name}}
    </div>
    <f7-tabs swipeable>
        <f7-page-content tab>
            <div class="content-wrap">
                <f7-block class='item'>
                    <div class="title">
                        Area jangkauan
                    </div>
                    <div class="info">{{detail.area}}</div>
                </f7-block>
            </div>
            <div class="content-wrap">
                <f7-block class='item'>
                    <div class="title">
                        Bunga
                    </div>
                    <div class="info" v-for="(item, n) in detail.interest_rate_text.split('\n')" :key="n" >{{item}}</div>
                </f7-block>
                <f7-block class='item'>
                    <div class="title">
                        Tingkat lulus
                    </div>
                    <div class="info">{{detail.pass_rate}}%</div>
                </f7-block>
            </div>
            <div class="content-wrap">
                <f7-block class='item'>
                    <div class="title">
                        Jenis pelunasan
                    </div>
                    <div class="info">{{detail.repayment_type}}</div>
                </f7-block>
                <f7-block class='item'>
                    <div class="title">
                        Metode pelunasan
                    </div>
                    <div class="info">{{detail.repayment_methods_text}}</div>
                </f7-block>
                <f7-block class='item'>
                    <div class="title">
                        Denda Keterlambatan
                    </div>
                    <div class="info">{{detail.default_rate_text}}</div>
                </f7-block>
                <f7-block class='item'>
                    <div class="title">
                        Waktu konfirmasi pembayaran kembali
                    </div>
                    <div class="info">{{detail.repayment_confirmation_time}}</div>
                </f7-block>
                <f7-block class='item'>
                    <div class="title">
                        Tingkat Penagihan
                    </div>
                    <div class="info">{{detail.dunning_effort}}</div>
                </f7-block>
            </div>
            <div class="content-wrap">
                <f7-block class='item'>
                    <div class="title">
                        Nama perusahaan
                    </div>
                    <div class="info">{{detail.company_name}}</div>
                </f7-block>
                <f7-block v-if="detail.news" class='item'>
                    <div class="title">
                        Berita Terbaru
                    </div>
                    <div class="info">{{detail.news}}</div>
                </f7-block>
                <f7-block v-if="/www.youtube.com/.test(detail.promote_video_url)" class='item'>
                    <div class="title">
                        Aktivitas terakhir
                    </div>
                    <div>
                        <iframe id="iframe" :src="detail.promote_video_url.replace('watch?v=', 'embed/')" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
                    </div>
                    <div class="info">{{detail.promote_video_desc}}</div>
                </f7-block>
            </div>
            <div id="footer">semua berpatokan pada APP sebagai acuan</div>
        </f7-page-content>
    </f7-tabs>
  </f7-page>
</template>
<script>
export default {
    name: 'installmentmoredetail',
    data() {
        return {
            pid: 0,
            detail: {
                interest_rate_text: '',
                pass_rate: '',
                repayment_type: '',
                repayment_methods_text: '',
                repayment_confirmation_time: '',
                default_rate_text: '',
                dunning_effort: '',
                company_name: '',
                news: '',
                promote_video_url: ''
            }
        }
    },
    created() {
        this.pid = this.$route.query.pid;
    },
    mounted() {
        // 详细信息
        this.$f7.showPreloader();
        this.axios.post(this.api.installmentDetails, {pid: this.pid})
        .then(response => {
            this.$f7.hidePreloader();
            this.detail = Object.assign({}, this.detail, response);
        })
        .catch(function (error) {
            this.$f7.hidePreloader();
        });
    }
}
</script>
